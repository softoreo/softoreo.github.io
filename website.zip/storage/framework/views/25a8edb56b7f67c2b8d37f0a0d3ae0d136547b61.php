<html>
    <head>
        <title>Visitor is here</title>
        <style>
            p{
                font-size: 14px;
                font-family: sans-serif, Verdana, 'Geneva', Tahoma;
            }
        </style>
    </head>
    <body>
        <ul>
            <li>Name: <?php echo e($visitor->name); ?></li>
            <li>Email: <?php echo e($visitor->email); ?></li>
            <li>Phone no: <?php echo e($visitor->phone); ?></li>
        </ul>
        <p><?php echo e($visitor->body); ?></p>
    </body>
</html>